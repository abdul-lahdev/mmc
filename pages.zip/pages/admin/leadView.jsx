import Tooltip from "../../components/Tooltip";
import UniversalDropdown from "../../components/UniversalDropdown";
import { Menu, MenuButton, MenuItem, MenuItems } from "@headlessui/react";
import { PhotoProvider, PhotoView } from "react-photo-view";
import "react-photo-view/dist/react-photo-view.css";
import { ChevronDownIcon } from "@heroicons/react/20/solid";
import { useState } from "react";
import Select from "react-select";
import { useEffect } from "react";
import {
  Dialog,
  DialogPanel,
  DialogTitle,
  DialogBackdrop,
  Transition,
} from "@headlessui/react";
import { Fragment } from "react";
import DatePicker from "../../components/Datepicker";

// here
import { ExclamationTriangleIcon } from "@heroicons/react/24/outline";

export default function LeadView() {
  const [selectedDate, setSelectedDate] = useState(null);
  const [activeTab, setActiveTab] = useState("Details");
  const [addFields, setAddFields] = useState(false);
  const [openIndex, setOpenIndex] = useState(0);
  const [urlText, setUrlText] = useState("www.example.com");
  const [paraAreaText, setParaAreaText] = useState("Add Description");
  const [task, setTask] = useState([]);
  const [taskSection, setTaskSection] = useState(false);
  // const [type, setType] = useState("");
  // const [address, setAddress] = useState("");
  // const [contAddress, setContAddress] = useState("");
  // const [city, setCity] = useState("");
  // const [state, setState] = useState("");
  // const [postalCode, setPostalCode] = useState("");
  // const [country, setCountry] = useState("");
  const [open, setOpen] = useState(false);
  const [fileOpen, setFileOpen] = useState(false);
  const [addressData, setAddressData] = useState([]);

  const [editorData, setEditorData] = useState("<p>Hello from CKEditor!</p>");
  // function addContent(e) {
  //   setAddressData([
  //     {
  //       type: type,
  //       address: address,
  //       contAddress: contAddress,
  //       city: city,
  //       state: state,
  //       postalCode: postalCode,
  //       country: country,
  //     },
  //   ]);
  // }

  const images = [
    {
      url: "/images/avatarsetting.png",
    },
    {
      url: "/images/avatarsetting.png",
    },
  ];

  function handlSubmit(e) {
    e.preventDefault();
    let form = e.target;
    let formData = new FormData(form);
    let formObj = Object.fromEntries(formData.entries());
    console.log(formObj);
    // setAddressData([formObj]);
    setAddressData((prev) => [...prev, formObj]);
    setAddFields(false);
  }

  function taskHandSubmit(e) {
    e.preventDefault();
    let form = e.target;
    let formData = new FormData(form);
    let formObj = Object.fromEntries(formData.entries());
    console.log(formObj);
    setTask((prev) => [...prev, formObj]);
    setTaskSection(false);
  }

  useEffect(() => {
    console.log("Updated addressData:", taskSection);
  }, [taskSection]);
  // const toggle = (index) => {
  //   setOpenIndex(openIndex === index ? null : index);
  // };

  useEffect(() => {
    console.log("Updated addressData:", addressData);
  }, [addressData]);
  const toggle = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const handleDelete = (deleteIndex) => {
    setAddressData((prev) => prev.filter((_, index) => index !== deleteIndex));
  };

  const options = [
    { value: "Pakistan", label: "Pakistan" },
    { value: "Iran", label: "Iran" },
    { value: "USA", label: "USA" },
    { value: "England", label: "England" },
    { value: "Africa", label: "Africa" },
    { value: "India", label: "India" },
    { value: "Bangladesh", label: "Bangladesh" },
    { value: "Colombia", label: "Colombia" },
  ];
  const userOpt = [{ value: "Abdullah Niaz", label: "Abdullah Niaz" }];
  const accordionData = [
    {
      title: "About",
      content: (
        <>
          <div className="flex items-center gap-3 group">
            <div>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 16 16"
                className="w-[20px] h-[20px]"
              >
                <path
                  fill="currentColor"
                  d="M10.457 6.264a2.193 2.193 0 1 1-4.385 0 2.193 2.193 0 0 1 4.385 0Zm-2.193-.878a.876.876 0 1 0 0 1.755.876.876 0 1 0 0-1.755Zm5.263.878c0 2.396-3.207 6.661-4.614 8.421a.828.828 0 0 1-1.3 0C6.184 12.925 3 8.66 3 6.264a5.264 5.264 0 1 1 10.527 0ZM8.264 2.316a3.949 3.949 0 0 0-3.948 3.948c0 .34.123.866.42 1.568.287.68.695 1.43 1.164 2.19.779 1.267 1.684 2.467 2.364 3.361.68-.893 1.584-2.094 2.363-3.36.469-.76.877-1.511 1.165-2.191.296-.702.42-1.228.42-1.568a3.949 3.949 0 0 0-3.948-3.948Z"
                ></path>
              </svg>
            </div>
            <div className="flex items-center justify-between w-full">
              <div
                className="cursor-pointer"
                onClick={() => {
                  setOpen(true);
                  addressData.length > 0
                    ? setAddFields(false)
                    : setAddFields(true);
                }}
              >
                {!addressData.length > 0 ? (
                  "Location"
                ) : (
                  <div>
                    <span className="inline-flex items-center rounded-[25px] bg-[#F8FAFC] px-4 py-1 text-[14px] font-[400] border text-[#90A1B9] border-solid border-[#90A1B9] ">
                      {addressData[0].type}
                    </span>
                    <p className="text-[#45556C] text-[14px] font-[400] mt-2">
                      {addressData[0].address}
                    </p>
                    <p className="text-[#45556C] text-[14px] font-[400]">
                      {addressData[0].contAddress}
                    </p>
                    <p className="text-[#45556C] text-[14px] font-[400]">
                      <span>{addressData[0].city}</span>,{" "}
                      <span>{addressData[0].state}</span>{" "}
                      <span>{addressData[0].postalCode}</span>
                    </p>
                    <p className="text-[#45556C] text-[14px] font-[400]">
                      {addressData[0].country}
                    </p>
                    <div>and {addressData.length} more</div>
                  </div>
                )}
              </div>
              <div>
                <span
                  onClick={() => {
                    setOpen(true);
                    addressData.length > 0
                      ? setAddFields(false)
                      : setAddFields(true);
                  }}
                  className="opacity-0 group-hover:opacity-100 transition duration-300 cursor-pointer"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 16 16"
                    className="w-[20px]"
                  >
                    <path
                      fill="currentColor"
                      d="M13.46 1.513a1.745 1.745 0 0 0-2.473 0l-8.754 8.754c-.234.234-.397.53-.47.853l-.754 3.358c-.056.251.16.522.427.522a.44.44 0 0 0 .088-.009s2.313-.49 3.357-.736c.316-.074.598-.233.828-.462L14.49 5.01a1.747 1.747 0 0 0-.002-2.472L13.46 1.513ZM4.78 12.864a.408.408 0 0 1-.2.113c-.497.117-1.298.293-1.988.443l.453-2.012a.437.437 0 0 1 .117-.214L9.776 4.58l1.644 1.644-6.641 6.64Z"
                    ></path>
                  </svg>
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3 mt-4">
            <div>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 16 16"
                className="w-[20px] h-[20px]"
              >
                <path
                  fill="currentColor"
                  d="M4.112 4.906a3.804 3.804 0 0 1 5.554 5.195l-.14.161a.636.636 0 0 1-.957-.835l.143-.162a2.536 2.536 0 0 0-.117-3.462C7.605 4.79 6 4.79 4.987 5.803L2.012 8.8a2.536 2.536 0 0 0 0 3.586c.944.921 2.46.995 3.462.117l.164-.143a.633.633 0 0 1 .894.06.633.633 0 0 1-.058.895l-.164.143a3.804 3.804 0 0 1-5.195-.175c-1.487-1.484-1.487-3.917 0-5.38l2.997-2.997zm7.776 6.587a3.806 3.806 0 0 1-5.382 0 3.784 3.784 0 0 1-.175-5.195l.124-.143a.636.636 0 0 1 .958.836l-.125.142a2.536 2.536 0 0 0 3.704 3.463l2.996-2.997a2.535 2.535 0 0 0-3.462-3.702l-.164.142a.634.634 0 0 1-.836-.956l.164-.142a3.804 3.804 0 0 1 5.195 5.554l-2.997 2.997z"
                ></path>
              </svg>
            </div>
            <div className="w-full">
              <input
                type="text"
                onChange={(e) => setUrlText(e.target.value)}
                value={urlText}
                className="h-[30px] cursor-pointer w-full px-3 hover:bg-[#F1F5F9] rounded-[8px] text-[#2860af] text-[16px] font-500 focus-visible:outline-[#d9dde1] focus-visible:text-[#90A1B9]"
              />
            </div>
          </div>
          <div className="flex items-start gap-3 mt-4">
            <div>
              <svg
                viewBox="0 0 14 15"
                fill="none"
                className="w-[20px] h-[20px]"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M1 3.14286C1 2.78661 1.28661 2.5 1.64286 2.5H12.3571C12.7134 2.5 13 2.78661 13 3.14286C13 3.49911 12.7134 3.78571 12.3571 3.78571H1.64286C1.28661 3.78571 1 3.49911 1 3.14286ZM1 7.42857C1 7.07232 1.28661 6.78571 1.64286 6.78571H12.3571C12.7134 6.78571 13 7.07232 13 7.42857C13 7.78482 12.7134 8.07143 12.3571 8.07143H1.64286C1.28661 8.07143 1 7.78482 1 7.42857ZM6.14286 11.7143C6.14286 12.0705 5.85625 12.3571 5.5 12.3571H1.64286C1.28661 12.3571 1 12.0705 1 11.7143C1 11.358 1.28661 11.0714 1.64286 11.0714H5.5C5.85625 11.0714 6.14286 11.358 6.14286 11.7143Z"
                  fill="currentColor"
                ></path>
              </svg>
            </div>
            <div className="w-full">
              <textarea
                type="text"
                onChange={(e) => setParaAreaText(e.target.value)}
                value={paraAreaText}
                className="h-[25px]  cursor-pointer w-full px-3 hover:bg-[#F1F5F9] rounded-[8px] text-[#90A1B9] text-[16px] font-500 focus-visible:outline-[#d9dde1] focus-visible:text-[#90A1B9]"
              ></textarea>
            </div>
          </div>
        </>
      ),
    },
    {
      title: "Task",
      content: (
        <>
          <div>
            {!task.length > 0 ? (
              <div
                className={`${
                  !taskSection ? "flex" : "hidden"
                }  flex-col items-center justify-center`}
              >
                <p className="text-center">
                  Assign actions to yourself or team members.
                </p>
                <span
                  onClick={() => setTaskSection(true)}
                  className="cursor-pointer text-[#245bc6] border-[transparent] border-b hover:border-[#245bc6] hover:border-b"
                >
                  Add Task
                </span>
              </div>
            ) : (
              <>
                <div className="flex flex-col gap-3">
                  {task.map((ele, index) => (
                    <div
                      className="flex items-center justify-between group"
                      key={index}
                    >
                      <div className="flex items-center gap-2">
                        <div className="rounded-[50%] bg-[#000] text-[#fff] text-[18px] w-[40px] h-[40px] flex items-center justify-center">
                          ss
                        </div>
                        <div>
                          <p className="text-[14px] text-[#0F172B] font-[500] ">
                            {ele.taskDescpt}
                          </p>
                          <p className="text-[12px] font-[400] text-[#45556C]">
                            {ele.date}
                          </p>
                        </div>
                      </div>
                      <div>
                        <span className="opacity-0 group-hover:opacity-100 transition duration-300 cursor-pointer">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 16 16"
                            className="w-[20px]"
                          >
                            <path
                              fill="currentColor"
                              d="M13.46 1.513a1.745 1.745 0 0 0-2.473 0l-8.754 8.754c-.234.234-.397.53-.47.853l-.754 3.358c-.056.251.16.522.427.522a.44.44 0 0 0 .088-.009s2.313-.49 3.357-.736c.316-.074.598-.233.828-.462L14.49 5.01a1.747 1.747 0 0 0-.002-2.472L13.46 1.513ZM4.78 12.864a.408.408 0 0 1-.2.113c-.497.117-1.298.293-1.988.443l.453-2.012a.437.437 0 0 1 .117-.214L9.776 4.58l1.644 1.644-6.641 6.64Z"
                            ></path>
                          </svg>
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex my-5">
                  <span
                    onClick={() => setTaskSection(true)}
                    className="cursor-pointer text-[#245bc6] border-[transparent] border-b hover:border-[#245bc6] hover:border-b"
                  >
                    Add Task
                  </span>
                </div>
              </>
            )}
          </div>
          <div className={`${taskSection ? "block" : "hidden"}`}>
            <form action="" onSubmit={taskHandSubmit}>
              <div>
                <input
                  type="text"
                  name="taskDescpt"
                  className="h-[44px] w-full px-3 bg-[#F1F5F9] rounded-[8px] text-[#90A1B9] text-[16px] font-500 focus-visible:outline-[#d9dde1]"
                  placeholder="Task Description"
                />
                <div className="reactSelectSetting w-full mt-3">
                  <Select name="userOpt" options={userOpt} />
                </div>
                <div className="mt-3">
                  <input
                    type="time"
                    name="time"
                    className="h-[44px] w-full px-3 bg-[#F1F5F9] rounded-[8px] text-[#90A1B9] text-[16px] font-500 focus-visible:outline-[#d9dde1]"
                  />
                </div>
                <div className="mt-3">
                  <DatePicker value={selectedDate} onChange={setSelectedDate} />
                </div>
                <div className="flex items-center justify-between mt-3">
                  <div className="cursor-pointer">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 16 16"
                      className="w-[20px] h-[20px]"
                    >
                      <path
                        fill="currentColor"
                        d="M13.813 3.188H11.56l-.93-1.552C10.37 1.24 9.968 1 9.51 1H6.74c-.459 0-.886.241-1.12.636l-.93 1.552H2.437A.436.436 0 0 0 2 3.624v.438c0 .243.195.437.438.437h.437v8.75c0 .967.783 1.75 1.75 1.75h7a1.75 1.75 0 0 0 1.75-1.75V4.5h.438a.435.435 0 0 0 .437-.438v-.437a.436.436 0 0 0-.438-.438ZM6.7 2.39a.162.162 0 0 1 .14-.079h2.57a.16.16 0 0 1 .14.08l.478.796H6.222L6.7 2.39Zm4.925 11.296h-7a.438.438 0 0 1-.438-.437V4.5h7.875v8.75c0 .24-.196.438-.437.438Zm-3.5-1.312a.437.437 0 0 0 .438-.438V6.25a.437.437 0 1 0-.876 0v5.688c0 .24.197.437.438.437Zm-2.188 0a.44.44 0 0 0 .438-.438V6.25a.437.437 0 1 0-.875 0v5.688c0 .24.197.437.438.437Zm4.375 0a.437.437 0 0 0 .438-.438V6.25a.437.437 0 1 0-.875 0v5.688c0 .24.197.437.438.437Z"
                      ></path>
                    </svg>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setTaskSection(false)}
                      className="flex items-center justify-center text-center h-[38px] gap-2 bg-[#F8FAFC] border border-[#F1F5F9] rounded-[60px] text-[#62748E] text-[12px] font-[700] leading-5 px-4 py-3 cursor-pointer select-none hover:bg-[#e5e5e5] "
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="flex items-center justify-center text-center h-[38px] gap-2 bg-[#2B7FFF] border border-[#8EC5FF] rounded-[60px] text-[#fff] text-[12px] font-[700] leading-5 px-4 py-3 cursor-pointer select-none hover:bg-[#2873e6] "
                    >
                      Save
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </>
      ),
    },
    {
      title: "Opportunity",
      content: `Flowbite is open-source and modular. Tailwind UI is a premium product with full page sections.`,
    },
  ];

  const dropDownOpt = [
    {
      name: "Status 01",
      url: "#",
    },
    {
      name: "Status 02",
      url: "#",
    },
    {
      name: "Status 03",
      url: "#",
    },
  ];

  //   const addressData = [
  //     {
  //       type: "",
  //       address: "",
  //       addressCount: "",
  //       city: "",
  //       state: "",
  //       postalCd: "",
  //       country: "",
  //     },
  //   ];

  return (
    <>
      {/* Address Moda */}
      <div>
        <Transition show={open} as={Fragment}>
          <Dialog as="div" className="relative z-10" onClose={setOpen}>
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0"
              enterTo="opacity-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100"
              leaveTo="opacity-0"
            >
              <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
            </Transition.Child>

            <div className="fixed inset-0 z-10 w-screen overflow-y-auto">
              <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
                <Transition.Child
                  as={Fragment}
                  enter="ease-out duration-300"
                  enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                  enterTo="opacity-100 translate-y-0 sm:scale-100"
                  leave="ease-in duration-200"
                  leaveFrom="opacity-100 translate-y-0 sm:scale-100"
                  leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                >
                  <DialogPanel className="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg">
                    <div
                      className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 overflow-y-auto"
                      style={{ scrollbarWidth: "none" }}
                    >
                      <div className="sm:flex sm:items-start">
                        <div className="w-full">
                          {addFields ? (
                            <form action="" onSubmit={handlSubmit}>
                              <div className="w-full">
                                <div className="flex justify-between">
                                  <h1 className="text-[#0F172B] text-[16px] font-[700]">
                                    Address
                                  </h1>
                                  <span
                                    onClick={() => setOpen(false)}
                                    className="cursor-pointer"
                                  >
                                    <svg
                                      xmlns="http://www.w3.org/2000/svg"
                                      fill="none"
                                      viewBox="0 0 16 16"
                                      className="w-[15px]"
                                    >
                                      <path
                                        fill="currentColor"
                                        d="M13.705 12.468a.896.896 0 0 1 0 1.27.902.902 0 0 1-1.273 0L8.001 9.284l-4.463 4.45a.902.902 0 0 1-1.273 0 .896.896 0 0 1 0-1.269l4.464-4.45-4.465-4.484a.896.896 0 0 1 0-1.27.902.902 0 0 1 1.272 0L8.001 6.75l4.463-4.451a.902.902 0 0 1 1.272 0 .896.896 0 0 1 0 1.27L9.272 8.016l4.433 4.45Z"
                                      ></path>
                                    </svg>
                                  </span>
                                </div>
                                <div className="w-full">
                                  <label
                                    htmlFor=""
                                    className="text-[#314158] text-[16px] font-[500] mb-2 block "
                                  >
                                    Type
                                  </label>
                                  <div className="relative w-full">
                                    <select
                                      name="type"
                                      className="appearance-none h-[44px] bg-[#F1F5F9] rounded-[8px] w-full px-4 py-2 pr-10 dark:bg-gray-800 dark:text-white text-sm focus:outline-none"
                                    >
                                      <option>Business</option>
                                      <option>Mailing</option>
                                      <option>Other</option>
                                    </select>
                                    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3">
                                      <svg
                                        className="w-4 h-4 dark:text-white"
                                        fill="none"
                                        stroke="currentColor"
                                        strokeWidth="2"
                                        viewBox="0 0 24 24"
                                      >
                                        <path
                                          strokeLinecap="round"
                                          strokeLinejoin="round"
                                          d="M19 9l-7 7-7-7"
                                        />
                                      </svg>
                                    </div>
                                  </div>
                                </div>
                                <div className="w-full mt-3">
                                  <label
                                    htmlFor=""
                                    className="text-[#314158] text-[16px] font-[500] mb-2 block "
                                  >
                                    Address
                                  </label>
                                  <div>
                                    <input
                                      type="text"
                                      name="address"
                                      required
                                      className="h-[44px] w-full px-3 bg-[#F1F5F9] rounded-[8px] text-[#90A1B9] text-[16px] font-500 focus-visible:outline-[#d9dde1]"
                                    />
                                  </div>
                                </div>
                                <div className="w-full mt-3">
                                  <label
                                    htmlFor=""
                                    className="text-[#314158] text-[16px] font-[500] mb-2 block "
                                  >
                                    Address (cont.)
                                  </label>
                                  <div>
                                    <input
                                      type="text"
                                      name="contAddress"
                                      className="h-[44px] w-full px-3 bg-[#F1F5F9] rounded-[8px] text-[#90A1B9] text-[16px] font-500 focus-visible:outline-[#d9dde1]"
                                    />
                                  </div>
                                </div>
                                <div className="grid xxl:grid-cols-[1fr_1fr] xl:grid-cols-[1fr_1fr] lg:grid-cols-[1fr_1fr] md:grid-cols-[1fr] sm:grid-cols-[1fr] gap-4">
                                  <div className="w-full mt-3">
                                    <label
                                      htmlFor=""
                                      className="text-[#314158] text-[16px] font-[500] mb-2 block "
                                    >
                                      City
                                    </label>
                                    <div>
                                      <input
                                        name="city"
                                        required
                                        type="text"
                                        className="h-[44px] w-full px-3 bg-[#F1F5F9] rounded-[8px] text-[#90A1B9] text-[16px] font-500 focus-visible:outline-[#d9dde1]"
                                      />
                                    </div>
                                  </div>
                                  <div className="w-full mt-3">
                                    <label
                                      htmlFor=""
                                      className="text-[#314158] text-[16px] font-[500] mb-2 block "
                                    >
                                      State
                                    </label>
                                    <div>
                                      <input
                                        required
                                        name="state"
                                        type="text"
                                        className="h-[44px] w-full px-3 bg-[#F1F5F9] rounded-[8px] text-[#90A1B9] text-[16px] font-500 focus-visible:outline-[#d9dde1]"
                                      />
                                    </div>
                                  </div>
                                </div>
                                <div className="grid xxl:grid-cols-[1fr_1fr] xl:grid-cols-[1fr_1fr] lg:grid-cols-[1fr_1fr] md:grid-cols-[1fr] sm:grid-cols-[1fr]  gap-4">
                                  <div className="w-full mt-3">
                                    <label
                                      htmlFor=""
                                      required
                                      className="text-[#314158] text-[16px] font-[500] mb-2 block "
                                    >
                                      Postal Code
                                    </label>
                                    <div>
                                      <input
                                        type="number"
                                        name="postalCode"
                                        required
                                        className="h-[44px] w-full px-3 bg-[#F1F5F9] rounded-[8px] text-[#90A1B9] text-[16px] font-500 focus-visible:outline-[#d9dde1]"
                                      />
                                    </div>
                                  </div>
                                  <div className="w-full mt-3">
                                    <label
                                      htmlFor=""
                                      className="text-[#314158] text-[16px] font-[500] mb-2 block "
                                    >
                                      Country
                                    </label>
                                    <div className="reactSelectSetting w-full">
                                      <Select
                                        name="country"
                                        options={options}
                                        styles={{
                                          menuPortal: (base) => ({
                                            ...base,
                                            zIndex: 9999,
                                          }),
                                        }}
                                      />
                                    </div>
                                  </div>
                                </div>
                                <div className="w-full mt-5 ">
                                  <div className="flex items-center w-full gap-3">
                                    <button
                                      onClick={() => setAddFields(false)}
                                      className="flex items-center justify-center text-center h-[38px] w-[50%] gap-2 bg-[#F8FAFC] border border-[#F1F5F9] rounded-[60px] text-[#62748E] text-[12px] font-[700] leading-5 px-4 py-3 cursor-pointer select-none hover:bg-[#e5e5e5] "
                                    >
                                      Cancel
                                    </button>
                                    <button
                                      type="submit"
                                      // onClick={addContent}
                                      className="flex items-center justify-center text-center h-[38px] w-[50%] gap-2 bg-[#2B7FFF] border border-[#8EC5FF] rounded-[60px] text-[#fff] text-[12px] font-[700] leading-5 px-4 py-3 cursor-pointer select-none hover:bg-[#2873e6] "
                                    >
                                      Save
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </form>
                          ) : (
                            <>
                              <div>
                                {addressData.map((ele, index) => (
                                  <div
                                    className="mt-3 flex items-center justify-between"
                                    key={index}
                                  >
                                    <div>
                                      <span className="inline-flex items-center rounded-[25px] bg-[#F8FAFC] px-4 py-1 text-[14px] font-[400] border text-[#90A1B9] border-solid border-[#90A1B9] ">
                                        {ele.type}
                                      </span>
                                      <p className="text-[#45556C] text-[14px] font-[400] mt-2">
                                        {ele.address}
                                      </p>
                                      <p className="text-[#45556C] text-[14px] font-[400]">
                                        {ele.contAddress}
                                      </p>
                                      <p className="text-[#45556C] text-[14px] font-[400]">
                                        <span>{ele.city}</span>,{" "}
                                        <span>{ele.state}</span>{" "}
                                        <span>{ele.postalCode}</span>
                                      </p>
                                      <p className="text-[#45556C] text-[14px] font-[400]">
                                        {ele.country}
                                      </p>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <Tooltip text="Edit" position="top">
                                        <span
                                          className="cursor-pointer"
                                          onClick={() => setAddFields(true)}
                                        >
                                          <svg
                                            className="w-[20px]"
                                            xmlns="http://www.w3.org/2000/svg"
                                            fill="none"
                                            viewBox="0 0 16 16"
                                          >
                                            <path
                                              fill="#90A1B9"
                                              d="M13.46 1.513a1.745 1.745 0 0 0-2.473 0l-8.754 8.754c-.234.234-.397.53-.47.853l-.754 3.358c-.056.251.16.522.427.522a.44.44 0 0 0 .088-.009s2.313-.49 3.357-.736c.316-.074.598-.233.828-.462L14.49 5.01a1.747 1.747 0 0 0-.002-2.472L13.46 1.513ZM4.78 12.864a.408.408 0 0 1-.2.113c-.497.117-1.298.293-1.988.443l.453-2.012a.437.437 0 0 1 .117-.214L9.776 4.58l1.644 1.644-6.641 6.64Z"
                                            ></path>
                                          </svg>
                                        </span>
                                      </Tooltip>
                                      <Tooltip text="Delete" position="top">
                                        <span
                                          className="cursor-pointer"
                                          onClick={() => handleDelete(index)}
                                        >
                                          <svg
                                            className="w-[20px]"
                                            xmlns="http://www.w3.org/2000/svg"
                                            fill="none"
                                            viewBox="0 0 16 16"
                                          >
                                            <path
                                              fill="#90A1B9"
                                              d="M13.813 3.188H11.56l-.93-1.552C10.37 1.24 9.968 1 9.51 1H6.74c-.459 0-.886.241-1.12.636l-.93 1.552H2.437A.436.436 0 0 0 2 3.624v.438c0 .243.195.437.438.437h.437v8.75c0 .967.783 1.75 1.75 1.75h7a1.75 1.75 0 0 0 1.75-1.75V4.5h.438a.435.435 0 0 0 .437-.438v-.437a.436.436 0 0 0-.438-.438ZM6.7 2.39a.162.162 0 0 1 .14-.079h2.57a.16.16 0 0 1 .14.08l.478.796H6.222L6.7 2.39Zm4.925 11.296h-7a.438.438 0 0 1-.438-.437V4.5h7.875v8.75c0 .24-.196.438-.437.438Zm-3.5-1.312a.437.437 0 0 0 .438-.438V6.25a.437.437 0 1 0-.876 0v5.688c0 .24.197.437.438.437Zm-2.188 0a.44.44 0 0 0 .438-.438V6.25a.437.437 0 1 0-.875 0v5.688c0 .24.197.437.438.437Zm4.375 0a.437.437 0 0 0 .438-.438V6.25a.437.437 0 1 0-.875 0v5.688c0 .24.197.437.438.437Z"
                                            ></path>
                                          </svg>
                                        </span>
                                      </Tooltip>
                                    </div>
                                  </div>
                                ))}
                              </div>
                              <div className="mt-5 border-t-[2px] border-[#F1F5F9] pt-5">
                                <button
                                  className="h-[38px] appearance-none bg-[#F1F5F9] hover:bg-gray-100 px-4 py-2 pr-10 dark:bg-gray-800 dark:text-white rounded-[60px] text-sm focus:outline-none"
                                  onClick={() => setAddFields(true)}
                                >
                                  + Add Address
                                </button>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </DialogPanel>
                </Transition.Child>
              </div>
            </div>
          </Dialog>
        </Transition>
      </div>
      {/*Address Moda */}

      {/* FILE VIEW MODAL */}
      <div>
        <Transition show={fileOpen} as={Fragment}>
          <Dialog as="div" className="relative z-10" onClose={setFileOpen}>
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0"
              enterTo="opacity-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100"
              leaveTo="opacity-0"
            >
              <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
            </Transition.Child>

            <div className="fixed inset-0 z-10 w-screen overflow-y-auto">
              <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
                <Transition.Child
                  as={Fragment}
                  enter="ease-out duration-300"
                  enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                  enterTo="opacity-100 translate-y-0 sm:scale-100"
                  leave="ease-in duration-200"
                  leaveFrom="opacity-100 translate-y-0 sm:scale-100"
                  leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                >
                  <DialogPanel className="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 w-full max-w-[80%]">
                    <div
                      className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 overflow-y-auto"
                      style={{ scrollbarWidth: "none" }}
                    >
                      <div>
                        <div className="flex items-center justify-between border-b border-[#f6f6f6] pb-3">
                          <div>
                            <span>Close (Example)</span>
                            <span> {">"} </span>
                            <span>Notes</span>
                          </div>
                          <span
                            className="cursor-pointer"
                            onClick={() => setFileOpen(false)}
                          >
                            X
                          </span>
                        </div>
                        <div className="grid grid-cols-[3fr_1fr]">
                          <div className="bg-[#F8FAFC] p-4 border-r border-[#f6f6f6]">
                            <div className="flex justify-between items-center">
                              <div>
                                <span>Notes</span>
                              </div>
                              <div>
                                <Menu
                                  as="div"
                                  className="relative inline-block text-left"
                                >
                                  <div>
                                    <MenuButton>
                                      <svg
                                        width="24"
                                        height="24"
                                        viewBox="0 0 24 24"
                                        fill="none"
                                        xmlns="http://www.w3.org/2000/svg"
                                      >
                                        {" "}
                                        <path
                                          d="M11.9993 12.6663C12.3675 12.6663 12.666 12.3679 12.666 11.9997C12.666 11.6315 12.3675 11.333 11.9993 11.333C11.6312 11.333 11.3327 11.6315 11.3327 11.9997C11.3327 12.3679 11.6312 12.6663 11.9993 12.6663Z"
                                          stroke="#90A1B9"
                                          strokeWidth="1.5"
                                          strokeLinecap="round"
                                          strokeLinejoin="round"
                                        />{" "}
                                        <path
                                          d="M16.666 12.6663C17.0342 12.6663 17.3327 12.3679 17.3327 11.9997C17.3327 11.6315 17.0342 11.333 16.666 11.333C16.2978 11.333 15.9993 11.6315 15.9993 11.9997C15.9993 12.3679 16.2978 12.6663 16.666 12.6663Z"
                                          stroke="#90A1B9"
                                          strokeWidth="1.5"
                                          strokeLinecap="round"
                                          strokeLinejoin="round"
                                        />{" "}
                                        <path
                                          d="M7.33268 12.6663C7.70087 12.6663 7.99935 12.3679 7.99935 11.9997C7.99935 11.6315 7.70087 11.333 7.33268 11.333C6.96449 11.333 6.66602 11.6315 6.66602 11.9997C6.66602 12.3679 6.96449 12.6663 7.33268 12.6663Z"
                                          stroke="#90A1B9"
                                          strokeWidth="1.5"
                                          strokeLinecap="round"
                                          strokeLinejoin="round"
                                        />{" "}
                                      </svg>
                                    </MenuButton>
                                  </div>

                                  <MenuItems
                                    transition
                                    className="absolute right-0 z-10 mt-2 w-56 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black/5 transition focus:outline-hidden data-closed:scale-95 data-closed:transform data-closed:opacity-0 data-enter:duration-100 data-enter:ease-out data-leave:duration-75 data-leave:ease-in"
                                  >
                                    <div className="py-1">
                                      <MenuItem>
                                        <a
                                          href="#"
                                          className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                                        >
                                          Delete
                                        </a>
                                      </MenuItem>
                                    </div>
                                  </MenuItems>
                                </Menu>
                              </div>
                            </div>
                            <div className="flex items-center justify-center">
                              <div className="bg-[#fff] w-[80%] p-4 rounded-[6px]">
                                <div className="flex items-center gap-3">
                                  <div className="w-[25px] h-[25px] bg-[black] rounded-[50%]"></div>
                                  <p>Jun 23</p>
                                  <span className="block w-[4px] h-[4px] rounded-[50%] bg-[#000]"></span>
                                  <span>
                                    <svg
                                      xmlns="http://www.w3.org/2000/svg"
                                      fill="none"
                                      viewBox="0 0 16 16"
                                      className="w-[20px] h-[20px]"
                                    >
                                      <path
                                        fill="currentColor"
                                        d="M13.46 1.513a1.745 1.745 0 0 0-2.473 0l-8.754 8.754c-.234.234-.397.53-.47.853l-.754 3.358c-.056.251.16.522.427.522a.44.44 0 0 0 .088-.009s2.313-.49 3.357-.736c.316-.074.598-.233.828-.462L14.49 5.01a1.747 1.747 0 0 0-.002-2.472L13.46 1.513ZM4.78 12.864a.408.408 0 0 1-.2.113c-.497.117-1.298.293-1.988.443l.453-2.012a.437.437 0 0 1 .117-.214L9.776 4.58l1.644 1.644-6.641 6.64Z"
                                      ></path>
                                    </svg>
                                  </span>
                                </div>
                                <div>
                                  <h1>Mobile Apps</h1>
                                  <p>
                                    Make sure to download our iOS and Android
                                    apps. They give you quick access to the most
                                    important features, while on the go:
                                  </p>
                                  <ul>
                                    <li className="list-disc ml-4">
                                      Email, SMS, and Calling
                                    </li>
                                    <li className="list-disc ml-4">Inbox</li>
                                    <li className="list-disc ml-4">
                                      Leads and Contacts
                                    </li>
                                    <li className="list-disc ml-4">
                                      Lead and Opportunity Management
                                    </li>
                                    <li className="list-disc ml-4">
                                      Reporting and Smart Views
                                    </li>
                                  </ul>
                                  <div>
                                    Attachments <span>1.95 MB</span>{" "}
                                  </div>
                                  <div className="mt-3">
                                    <PhotoProvider>
                                      <div className="foo flex gap-3">
                                        {images.map((item, index) => (
                                          <PhotoView key={index} src={item.url}>
                                            <img
                                              src={item.url}
                                              alt=""
                                              className="w-[100px] h-[50px] object-cover  cursor-pointer rounded-[6px]"
                                            />
                                          </PhotoView>
                                        ))}
                                      </div>
                                    </PhotoProvider>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="p-4">
                            <div className="">0 comments</div>
                            <div className="mt-4 grid grid-cols-[15%_85%] items-center">
                              <div className="w-[30px] h-[30px] bg-black rounded-[50%]"></div>
                              <textarea className="min-h-[40px] resize-none w-full px-3 hover:bg-[#F1F5F9] rounded-[8px] border border-[#d9dde1] text-[#202020] text-[16px] font-500 focus-visible:outline-[#d9dde1] focus-visible:text-[#90A1B9]"></textarea>
                            </div>
                            <div className="mt-3 flex justify-end">
                              <button className="bg-[#e3e3e3] px-2 py-1 rounded-md">
                                Send
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </DialogPanel>
                </Transition.Child>
              </div>
            </div>
          </Dialog>
        </Transition>
      </div>
      {/* FILE VIEW MODAL  END*/}
      <div className="border-b-[2px] border-[#F1F5F9] pb-5 grid xxl:grid-cols-[1fr_1fr] xl:grid-cols-[1fr_1fr] lg:grid-cols-[1fr_1fr] md:grid-cols-[1fr] sm:grid-cols-[1fr] grid-cols-[1fr] gap-4">
        <div className="flex items-center gap-3">
          <div className="w-[48px] h-[48px] rounded-[50%] border border-[#CAD5E2] bg-[#F1F5F9] flex items-center justify-center text-[#45556C] text-[14px] font-[600]">
            LN
          </div>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="font-[700] text-[18px] text-[#0F172B]">
                Lead Name
              </h1>
              <span>hel</span>
            </div>
            <p className="text-[#90A1B9] text-[12px] font-[500] ">
              Last Updated <span>01/12/25 (10:00 am)</span>
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3 justify-end">
          <div>
            <Tooltip text="Fint Match Finder" position="bottom">
              <button className="h-[38px] flex items-center gap-2 bg-[#2B7FFF] border border-[#8EC5FF] rounded-[60px] text-[#fff] text-[12px] font-[700] leading-5 px-4 py-3 text-center cursor-pointer select-none hover:bg-[#2873e6] ">
                <span>
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 16 16"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    {" "}
                    <path
                      d="M4.66667 5.66667H8M4.66667 8H10M4.66667 12V13.557C4.66667 13.9122 4.66667 14.0898 4.73949 14.1811C4.80282 14.2604 4.89885 14.3066 5.00036 14.3065C5.11708 14.3063 5.25578 14.1954 5.53317 13.9735L7.12348 12.7012C7.44834 12.4413 7.61078 12.3114 7.79166 12.219C7.95213 12.137 8.12295 12.0771 8.29948 12.0408C8.49845 12 8.70646 12 9.1225 12H10.8C11.9201 12 12.4802 12 12.908 11.782C13.2843 11.5903 13.5903 11.2843 13.782 10.908C14 10.4802 14 9.9201 14 8.8V5.2C14 4.07989 14 3.51984 13.782 3.09202C13.5903 2.71569 13.2843 2.40973 12.908 2.21799C12.4802 2 11.9201 2 10.8 2H5.2C4.0799 2 3.51984 2 3.09202 2.21799C2.71569 2.40973 2.40973 2.71569 2.21799 3.09202C2 3.51984 2 4.07989 2 5.2V9.33333C2 9.95331 2 10.2633 2.06815 10.5176C2.25308 11.2078 2.79218 11.7469 3.48236 11.9319C3.7367 12 4.04669 12 4.66667 12Z"
                      stroke="white"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />{" "}
                  </svg>
                </span>
                Match Funder
              </button>
            </Tooltip>
          </div>
          <div>
            <Tooltip text="This is a tooltip!" position="bottome">
              <button className="h-[38px] w-[38px] flex items-center justify-center bg-[#F8FAFC] border border-[#F1F5F9] rounded-[50%] text-gray-900 text-sm font-semibold leading-5  text-center shadow-sm cursor-pointer select-none hover:bg-gray-50 focus:outline focus:outline-2 focus:outline-gray-200 focus:outline-offset-2 focus-visible:shadow-none">
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 16 16"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  {" "}
                  <g clip-path="url(#clip0_450_7807)">
                    {" "}
                    <path
                      d="M8.44185 1.16943L0.228516 14.7929C6.97518 14.8665 6.40025 15.3241 9.78478 9.44143L8.53572 7.36997L5.82105 11.8958C5.45198 12.5294 4.68932 12.7844 3.98318 12.7214L8.44398 5.3241L14.1538 14.7929H15.773V13.2846C15.773 13.2846 9.51385 2.9401 8.44185 1.16943Z"
                      fill="#62748E"
                    />{" "}
                    <path
                      d="M13.4157 3.91895H11.2109L12.3533 5.81441L13.4147 3.91895H13.4157Z"
                      fill="#62748E"
                    />{" "}
                  </g>{" "}
                  <defs>
                    {" "}
                    <clipPath id="clip0_450_7807">
                      {" "}
                      <rect width="16" height="16" fill="white" />{" "}
                    </clipPath>{" "}
                  </defs>{" "}
                </svg>
              </button>
            </Tooltip>
          </div>
          <div className="h-[38px] flex overflow-hidden bg-[#F8FAFC] border divide-x rounded-[40px] rtl:flex-row-reverse dark:bg-gray-900 dark:border-gray-700 dark:divide-gray-700">
            <button className="flex items-center gap-2 px-4 py-2 font-medium text-gray-600 transition-colors duration-200 sm:px-6 dark:hover:bg-gray-800 dark:text-gray-300 hover:bg-gray-100">
              <svg
                width="16"
                height="16"
                viewBox="0 0 16 16"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                {" "}
                <g clip-path="url(#clip0_450_7817)">
                  {" "}
                  <path
                    d="M9.36709 4.00016C10.0182 4.12721 10.6167 4.44567 11.0858 4.91479C11.5549 5.38391 11.8734 5.98234 12.0004 6.6335M9.36709 1.3335C10.7199 1.48379 11.9815 2.08961 12.9446 3.0515C13.9077 4.01339 14.5151 5.27417 14.6671 6.62683M6.81841 9.24221C6.01736 8.44116 5.38483 7.5354 4.92084 6.56898C4.88092 6.48586 4.86097 6.44429 4.84564 6.3917C4.79115 6.2048 4.83029 5.97529 4.94363 5.817C4.97552 5.77246 5.01363 5.73436 5.08984 5.65815C5.32291 5.42508 5.43944 5.30854 5.51563 5.19136C5.80296 4.74943 5.80296 4.17971 5.51563 3.73778C5.43944 3.6206 5.32291 3.50406 5.08984 3.27099L4.95992 3.14108C4.60563 2.78678 4.42848 2.60964 4.23823 2.51341C3.85985 2.32203 3.41301 2.32203 3.03464 2.51341C2.84438 2.60964 2.66723 2.78678 2.31294 3.14108L2.20785 3.24617C1.85477 3.59925 1.67823 3.77579 1.54339 4.01581C1.39378 4.28215 1.28621 4.69581 1.28712 5.00129C1.28793 5.27659 1.34134 5.46474 1.44814 5.84104C2.02212 7.8633 3.1051 9.77154 4.69709 11.3635C6.28908 12.9555 8.19732 14.0385 10.2196 14.6125C10.5959 14.7193 10.784 14.7727 11.0593 14.7735C11.3648 14.7744 11.7785 14.6668 12.0448 14.5172C12.2848 14.3824 12.4614 14.2059 12.8145 13.8528L12.9195 13.7477C13.2738 13.3934 13.451 13.2162 13.5472 13.026C13.7386 12.6476 13.7386 12.2008 13.5472 11.8224C13.451 11.6321 13.2738 11.455 12.9195 11.1007L12.7896 10.9708C12.5566 10.7377 12.44 10.6212 12.3228 10.545C11.8809 10.2577 11.3112 10.2577 10.8693 10.545C10.7521 10.6212 10.6355 10.7377 10.4025 10.9708C10.3263 11.047 10.2882 11.0851 10.2436 11.117C10.0853 11.2303 9.85582 11.2695 9.66892 11.215C9.61633 11.1997 9.57476 11.1797 9.49164 11.1398C8.52523 10.6758 7.61946 10.0433 6.81841 9.24221Z"
                    stroke="#62748E"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />{" "}
                </g>{" "}
                <defs>
                  {" "}
                  <clipPath id="clip0_450_7817">
                    {" "}
                    <rect width="16" height="16" fill="white" />{" "}
                  </clipPath>{" "}
                </defs>{" "}
              </svg>
              <span className="text-[12px] text-[#62748E] font-[500]">
                Call
              </span>
            </button>
            <button className="flex items-center gap-2 px-4 py-2 font-medium text-gray-600 transition-colors duration-200 sm:px-6 dark:hover:bg-gray-800 dark:text-gray-300 hover:bg-gray-100">
              <svg
                width="16"
                height="16"
                viewBox="0 0 16 16"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                {" "}
                <path
                  d="M4.66667 5.66667H8M4.66667 8H10M4.66667 12V13.557C4.66667 13.9122 4.66667 14.0898 4.73949 14.1811C4.80282 14.2604 4.89885 14.3066 5.00036 14.3065C5.11708 14.3063 5.25578 14.1954 5.53317 13.9735L7.12348 12.7012C7.44834 12.4413 7.61078 12.3114 7.79166 12.219C7.95213 12.137 8.12295 12.0771 8.29948 12.0408C8.49845 12 8.70646 12 9.1225 12H10.8C11.9201 12 12.4802 12 12.908 11.782C13.2843 11.5903 13.5903 11.2843 13.782 10.908C14 10.4802 14 9.9201 14 8.8V5.2C14 4.07989 14 3.51984 13.782 3.09202C13.5903 2.71569 13.2843 2.40973 12.908 2.21799C12.4802 2 11.9201 2 10.8 2H5.2C4.0799 2 3.51984 2 3.09202 2.21799C2.71569 2.40973 2.40973 2.71569 2.21799 3.09202C2 3.51984 2 4.07989 2 5.2V9.33333C2 9.95331 2 10.2633 2.06815 10.5176C2.25308 11.2078 2.79218 11.7469 3.48236 11.9319C3.7367 12 4.04669 12 4.66667 12Z"
                  stroke="#62748E"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />{" "}
              </svg>
              <span className="text-[12px] text-[#62748E] font-[500]">SMS</span>
            </button>
            <button className="flex items-center gap-2 px-4 py-2 font-medium text-gray-600 transition-colors duration-200 sm:px-6 dark:hover:bg-gray-800 dark:text-gray-300 hover:bg-gray-100">
              <svg
                width="16"
                height="16"
                viewBox="0 0 16 16"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                {" "}
                <path
                  d="M14.334 11.9998L9.90541 7.99984M6.09589 7.99984L1.66734 11.9998M1.33398 4.6665L6.77726 8.4768C7.21804 8.78535 7.43844 8.93962 7.67816 8.99938C7.88991 9.05216 8.11139 9.05216 8.32314 8.99938C8.56287 8.93962 8.78326 8.78535 9.22404 8.4768L14.6673 4.6665M4.53398 13.3332H11.4673C12.5874 13.3332 13.1475 13.3332 13.5753 13.1152C13.9516 12.9234 14.2576 12.6175 14.4493 12.2412C14.6673 11.8133 14.6673 11.2533 14.6673 10.1332V5.8665C14.6673 4.7464 14.6673 4.18635 14.4493 3.75852C14.2576 3.3822 13.9516 3.07624 13.5753 2.88449C13.1475 2.6665 12.5874 2.6665 11.4673 2.6665H4.53398C3.41388 2.6665 2.85383 2.6665 2.426 2.88449C2.04968 3.07624 1.74372 3.3822 1.55197 3.75852C1.33398 4.18635 1.33398 4.7464 1.33398 5.8665V10.1332C1.33398 11.2533 1.33398 11.8133 1.55197 12.2412C1.74372 12.6175 2.04968 12.9234 2.426 13.1152C2.85383 13.3332 3.41388 13.3332 4.53398 13.3332Z"
                  stroke="#62748E"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />{" "}
              </svg>
              <span className="text-[12px] text-[#62748E] font-[500]">
                Email
              </span>
            </button>
          </div>
          <div>
            <Tooltip text="Change lead Status" position="bottom">
              <div className="relative w-full">
                <select className="h-[38px] appearance-none bg-[#F1F5F9] hover:bg-gray-100 w-full px-4 py-2 pr-10 dark:bg-gray-800 dark:text-white rounded-[60px] text-sm focus:outline-none">
                  <option className="border border-[red] rounded-[12px]">
                    Lead Status
                  </option>
                  <option>Status 01</option>
                  <option>Status 02</option>
                  <option>Status 03</option>
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3">
                  <svg
                    className="w-4 h-4 dark:text-white"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M19 9l-7 7-7-7"
                    />
                  </svg>
                </div>
              </div>
            </Tooltip>
          </div>
        </div>
      </div>
      <div className="grid xxl:grid-cols-[1fr_3fr] xl:grid-cols-[1fr_3fr]">
        <div>
          {/* HERE */}
          <div className="flex space-x-4 border-b dark:border-gray-700 h-[54px]">
            {["Details", "Files"].map((tab) => (
              <button
                key={tab}
                className={`px-4 py-2 font-medium text-sm ${
                  activeTab === tab
                    ? "border-b-2 border-red-600 text-red-600"
                    : "text-gray-600 dark:text-gray-300"
                }`}
                onClick={() => setActiveTab(tab)}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>

          {activeTab === "Details" && (
            <div className="max-w-2xl mx-auto bg-white">
              {accordionData.map((item, index) => (
                <div
                  key={index}
                  className="border border-[#F1F5F9] mt-5 rounded-[6px] "
                >
                  <button
                    onClick={() => toggle(index)}
                    className="w-full rounded-[6px] rounded-bl-[0] rounded-br-[0] flex items-center bg-[#F1F5F9] justify-between py-3 px-4 text-left text-[#020618] text-[14px] font-medium hover:bg-gray-100"
                  >
                    <div className="flex items-center gap-2">
                      <span>{item.title}</span>
                      {item.title === "Task" ? <span>+</span> : ""}
                    </div>
                    <ChevronDownIcon
                      className={`w-5 h-5 text-gray-500 transition-transform duration-300 ${
                        openIndex === index ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                  {openIndex === index && (
                    <div className="px-5 py-4 text-gray-600">
                      {item.content}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {activeTab === "Files" && (
            <div>
              <div className="flex gap-3 items-center">
                <div class="flex-1">
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <svg
                        class="h-5 w-5 text-[#62748E]"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          strokeLinecap="round"
                          stroke-linejoin="round"
                          stroke-width="2"
                          d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                        ></path>
                      </svg>
                    </div>
                    <input
                      type="text"
                      className="block w-full pl-10 pr-3 py-2 dark:border-gray-600 rounded-[26px] bg-[#F8FAFC] dark:bg-gray-800 focus:outline-none focus:ring-1 focus:ring-accent focus:border-accent dark:text-white"
                      placeholder="Search by activity"
                    />
                  </div>
                </div>
                <Tooltip text="All Types" position="bottom">
                  {/* <div className="cursor-pointer">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 16 16"
                      className="w-[20px] h-[20px]"
                    >
                      <path
                        fill="#777"
                        fill-rule="evenodd"
                        d="M4.893 1a.612.612 0 0 0-.613.613v11.024c0 .339.274.613.613.613h7.962a.612.612 0 0 0 .612-.613V4.675L9.793 1h-4.9Z"
                        clip-rule="evenodd"
                      ></path>
                      <path
                        fill="#000"
                        fill-opacity=".2"
                        d="m9.793 1 3.675 3.675H10.71a.919.919 0 0 1-.918-.919V1Z"
                      ></path>
                      <path
                        fill="#C6C6C6"
                        fill-rule="evenodd"
                        d="M3.143 2.75a.612.612 0 0 0-.613.612v11.025c0 .339.274.613.613.613h7.962a.612.612 0 0 0 .612-.613V6.425L8.043 2.75h-4.9Z"
                        clip-rule="evenodd"
                      ></path>
                      <path
                        fill="#000"
                        fill-opacity=".2"
                        d="m8.043 2.75 3.675 3.675H8.96a.919.919 0 0 1-.918-.919V2.75Z"
                      ></path>
                    </svg>
                  </div> */}
                  <Menu as="div" className="relative inline-block text-left">
                    <div>
                      <MenuButton>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 16 16"
                          className="w-[20px] h-[20px]"
                        >
                          <path
                            fill="#777"
                            fill-rule="evenodd"
                            d="M4.893 1a.612.612 0 0 0-.613.613v11.024c0 .339.274.613.613.613h7.962a.612.612 0 0 0 .612-.613V4.675L9.793 1h-4.9Z"
                            clip-rule="evenodd"
                          ></path>
                          <path
                            fill="#000"
                            fill-opacity=".2"
                            d="m9.793 1 3.675 3.675H10.71a.919.919 0 0 1-.918-.919V1Z"
                          ></path>
                          <path
                            fill="#C6C6C6"
                            fill-rule="evenodd"
                            d="M3.143 2.75a.612.612 0 0 0-.613.612v11.025c0 .339.274.613.613.613h7.962a.612.612 0 0 0 .612-.613V6.425L8.043 2.75h-4.9Z"
                            clip-rule="evenodd"
                          ></path>
                          <path
                            fill="#000"
                            fill-opacity=".2"
                            d="m8.043 2.75 3.675 3.675H8.96a.919.919 0 0 1-.918-.919V2.75Z"
                          ></path>
                        </svg>
                      </MenuButton>
                    </div>

                    <MenuItems
                      transition
                      className="absolute right-0 z-10 mt-2 w-56 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black/5 transition focus:outline-hidden data-closed:scale-95 data-closed:transform data-closed:opacity-0 data-enter:duration-100 data-enter:ease-out data-leave:duration-75 data-leave:ease-in"
                    >
                      <div className="py-1">
                        <MenuItem>
                          <a
                            href="#"
                            className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                          >
                            All types
                          </a>
                        </MenuItem>
                        <MenuItem>
                          <a
                            href="#"
                            className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                          >
                            Images
                          </a>
                        </MenuItem>
                        <MenuItem>
                          <a
                            href="#"
                            className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                          >
                            PDFs
                          </a>
                        </MenuItem>
                        <MenuItem>
                          <a
                            href="#"
                            className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                          >
                            Documents
                          </a>
                        </MenuItem>
                        <MenuItem>
                          <a
                            href="#"
                            className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                          >
                            Spreadsheets & CSVs
                          </a>
                        </MenuItem>
                        <MenuItem>
                          <a
                            href="#"
                            className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                          >
                            Slides
                          </a>
                        </MenuItem>
                        <MenuItem>
                          <a
                            href="#"
                            className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                          >
                            Video
                          </a>
                        </MenuItem>
                        <MenuItem>
                          <a
                            href="#"
                            className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                          >
                            Audio
                          </a>
                        </MenuItem>
                        <MenuItem>
                          <a
                            href="#"
                            className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                          >
                            Compressed files
                          </a>
                        </MenuItem>
                      </div>
                    </MenuItems>
                  </Menu>
                </Tooltip>
                <Tooltip text="Filter" position="bottom">
                  <Menu as="div" className="relative inline-block text-left">
                    <div>
                      <MenuButton>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 16 16"
                          className="w-[20px] h-[20px]"
                        >
                          <path
                            fill="currentColor"
                            d="M10 13.5H8.667c-.368 0-.667.336-.667.75s.3.75.667.75H10c.368 0 .642-.336.642-.75s-.275-.75-.642-.75Zm1.753-4H8.667C8.3 9.5 8 9.838 8 10.25s.3.75.667.75h3.086c.368 0 .666-.336.666-.75s-.275-.75-.666-.75Zm1.777-4H8.668C8.3 5.5 8 5.838 8 6.25s.3.75.667.75h4.864c.368 0 .666-.336.666-.75s-.275-.75-.666-.75Zm1.778-4H8.667C8.3 1.5 8 1.836 8 2.25s.3.75.667.75h6.641c.368 0 .667-.336.667-.75s-.275-.75-.667-.75Zm-9.575 8.972-1.51 1.869V1.75c0-.415-.298-.751-.667-.751-.37 0-.667.336-.667.75V12.34l-1.51-1.84a.631.631 0 0 0-.49-.241.624.624 0 0 0-.452.2.818.818 0 0 0-.037 1.06l2.64 3.251a.636.636 0 0 0 .98 0l2.641-3.253a.818.818 0 0 0-.037-1.06c-.222-.286-.644-.264-.892.014Z"
                          ></path>
                        </svg>
                      </MenuButton>
                    </div>

                    <MenuItems
                      transition
                      className="absolute right-0 z-10 mt-2 w-56 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black/5 transition focus:outline-hidden data-closed:scale-95 data-closed:transform data-closed:opacity-0 data-enter:duration-100 data-enter:ease-out data-leave:duration-75 data-leave:ease-in"
                    >
                      <div className="py-1">
                        <MenuItem>
                          <a
                            href="#"
                            className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                          >
                            File name (A to Z)
                          </a>
                        </MenuItem>
                        <MenuItem>
                          <a
                            href="#"
                            className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                          >
                            File name (Z to A)
                          </a>
                        </MenuItem>
                        <MenuItem>
                          <a
                            href="#"
                            className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                          >
                            Latest activity (old to New)
                          </a>
                        </MenuItem>
                        <MenuItem>
                          <a
                            href="#"
                            className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                          >
                            Latest activity (New to Old)
                          </a>
                        </MenuItem>
                        <MenuItem>
                          <a
                            href="#"
                            className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                          >
                            File size (Small to Large)
                          </a>
                        </MenuItem>
                        <MenuItem>
                          <a
                            href="#"
                            className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                          >
                            File size (Large to Small)
                          </a>
                        </MenuItem>
                      </div>
                    </MenuItems>
                  </Menu>
                </Tooltip>
                <Tooltip text="Upload File" position="bottom">
                  <div className="cursor-pointer">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 16 16"
                      className="w-[20px] h-[20px]"
                    >
                      <path
                        fill="currentColor"
                        d="M7.344 10.406v-1.75h-1.75A.655.655 0 0 1 4.937 8c0-.364.293-.656.657-.656h1.75v-1.75c0-.364.292-.657.656-.657.364 0 .656.293.656.657v1.75h1.75c.364 0 .656.292.656.656a.655.655 0 0 1-.656.656h-1.75v1.75a.655.655 0 0 1-.656.656.655.655 0 0 1-.656-.656ZM15 8a7 7 0 0 1-7 7 7 7 0 0 1-7-7 7 7 0 0 1 7-7 7 7 0 0 1 7 7ZM8 2.312A5.687 5.687 0 0 0 2.312 8 5.687 5.687 0 0 0 8 13.688 5.687 5.687 0 0 0 13.688 8 5.687 5.687 0 0 0 8 2.312Z"
                      ></path>
                    </svg>
                  </div>
                </Tooltip>
              </div>
              <div className="mt-3 ">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="">
                      <svg
                        width="24"
                        height="32"
                        viewBox="0 0 24 32"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        {" "}
                        <g clipPath="url(#clip0_649_11443)">
                          {" "}
                          <path
                            d="M0 8C0 3.58172 3.58172 0 8 0H13.6L24 10.4V24C24 28.4183 20.4183 32 16 32H8C3.58172 32 0 28.4183 0 24V8Z"
                            fill="url(#paint0_linear_649_11443)"
                          />{" "}
                          <path
                            d="M19.5996 10.4H23.9996L13.5996 0V4.4C13.5996 7.71371 16.2859 10.4 19.5996 10.4Z"
                            fill="#DCE2EB"
                          />{" "}
                          <path
                            d="M8 1H13.1855L23 10.8145V24C23 27.866 19.866 31 16 31H8C4.13401 31 1 27.866 1 24V8C1 4.13401 4.13401 1 8 1Z"
                            stroke="black"
                            strokeOpacity="0.06"
                            strokeWidth="2"
                          />{" "}
                        </g>{" "}
                        <defs>
                          {" "}
                          <linearGradient
                            id="paint0_linear_649_11443"
                            x1="12"
                            y1="0"
                            x2="12"
                            y2="32"
                            gradientUnits="userSpaceOnUse"
                          >
                            {" "}
                            <stop stop-color="#F2F6FC" />{" "}
                            <stop offset="1" stop-color="#EDF1F7" />{" "}
                          </linearGradient>{" "}
                          <clipPath id="clip0_649_11443">
                            {" "}
                            <rect width="24" height="32" fill="white" />{" "}
                          </clipPath>{" "}
                        </defs>{" "}
                      </svg>
                    </div>
                    <div>
                      <p className="">fileName</p>
                      <div className="flex items-center gap-2">
                        <span className="text-[#90A1B9] font-[400] text-[10px]">
                          01/12/25 (10:00 am)
                        </span>
                        <span className="block w-[4px] h-[4px] bg-[#CAD5E2] rounded-[50%]"></span>
                        <span className="text-[#90A1B9] text-[10px] font-[400]">
                          275kb
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="mt-2">
                      <Menu
                        as="div"
                        className="relative inline-block text-left"
                      >
                        <div>
                          <MenuButton>
                            <svg
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              {" "}
                              <path
                                d="M11.9993 12.6663C12.3675 12.6663 12.666 12.3679 12.666 11.9997C12.666 11.6315 12.3675 11.333 11.9993 11.333C11.6312 11.333 11.3327 11.6315 11.3327 11.9997C11.3327 12.3679 11.6312 12.6663 11.9993 12.6663Z"
                                stroke="#90A1B9"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                              />{" "}
                              <path
                                d="M16.666 12.6663C17.0342 12.6663 17.3327 12.3679 17.3327 11.9997C17.3327 11.6315 17.0342 11.333 16.666 11.333C16.2978 11.333 15.9993 11.6315 15.9993 11.9997C15.9993 12.3679 16.2978 12.6663 16.666 12.6663Z"
                                stroke="#90A1B9"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                              />{" "}
                              <path
                                d="M7.33268 12.6663C7.70087 12.6663 7.99935 12.3679 7.99935 11.9997C7.99935 11.6315 7.70087 11.333 7.33268 11.333C6.96449 11.333 6.66602 11.6315 6.66602 11.9997C6.66602 12.3679 6.96449 12.6663 7.33268 12.6663Z"
                                stroke="#90A1B9"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                              />{" "}
                            </svg>
                          </MenuButton>
                        </div>

                        <MenuItems
                          transition
                          className="absolute right-0 z-10 mt-2 w-56 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black/5 transition focus:outline-hidden data-closed:scale-95 data-closed:transform data-closed:opacity-0 data-enter:duration-100 data-enter:ease-out data-leave:duration-75 data-leave:ease-in"
                        >
                          <div className="py-1">
                            <MenuItem>
                              <a
                                href="#"
                                className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                              >
                                View
                              </a>
                            </MenuItem>
                            <MenuItem>
                              <a
                                href="#"
                                className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                              >
                                Download
                              </a>
                            </MenuItem>
                            <MenuItem>
                              <a
                                href="#"
                                className="block px-4 py-2 text-sm text-gray-700 data-focus:bg-gray-100 data-focus:text-gray-900 data-focus:outline-hidden"
                              >
                                Copy activity link
                              </a>
                            </MenuItem>
                          </div>
                        </MenuItems>
                      </Menu>
                    </span>
                    <span
                      onClick={() => {
                        setFileOpen(true);
                      }}
                      className="cursor-pointer"
                    >
                      <svg
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        {" "}
                        <path
                          d="M13.3327 11.333H9.33268M10.666 13.9997H9.33268M14.666 8.66634H9.33268M17.3327 10.9997V8.53301C17.3327 7.4129 17.3327 6.85285 17.1147 6.42503C16.9229 6.0487 16.617 5.74274 16.2407 5.55099C15.8128 5.33301 15.2528 5.33301 14.1327 5.33301H9.86602C8.74591 5.33301 8.18586 5.33301 7.75803 5.55099C7.38171 5.74274 7.07575 6.0487 6.884 6.42503C6.66602 6.85285 6.66602 7.4129 6.66602 8.53301V15.4663C6.66602 16.5864 6.66602 17.1465 6.884 17.5743C7.07575 17.9506 7.38171 18.2566 7.75803 18.4484C8.18586 18.6663 8.74591 18.6663 9.86602 18.6663H11.666M18.666 18.6663L17.666 17.6663M18.3327 15.9997C18.3327 17.2883 17.288 18.333 15.9993 18.333C14.7107 18.333 13.666 17.2883 13.666 15.9997C13.666 14.711 14.7107 13.6663 15.9993 13.6663C17.288 13.6663 18.3327 14.711 18.3327 15.9997Z"
                          stroke="#90A1B9"
                          strokeWidth="1.5"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />{" "}
                      </svg>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* HERE END */}
        </div>
        <div>
          <div className="h-[54px] border-b dark:border-gray-700 flex items-center justify-between px-3">
            <div>left</div>
            <div>Right</div>
          </div>
        </div>
      </div>
    </>
  );
}
